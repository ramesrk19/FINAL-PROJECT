package com.phase4.mentor;

import org.springframework.data.repository.CrudRepository;

public interface Skillsrep extends CrudRepository<Skills, Integer>{
	 
}
