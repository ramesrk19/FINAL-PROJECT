package com.phase4.mentor;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.springframework.data.jpa.repository.Query;

@Entity
public class Training {
	
	@Id
	private String coursename;
	
	private Integer percentage;
	
	private Integer amountpaid;
	
	private Integer amountremaining;
	
	private Boolean status;

	public Training() {
		super();
	}

	public Training(String coursename, Integer percentage, Integer amountpaid, Integer amountremaining,
			Boolean status) {
		super();
		this.coursename = coursename;
		this.percentage = percentage;
		this.amountpaid = amountpaid;
		this.amountremaining = amountremaining;
		this.status = status;
	}

	public String getCoursename() {
		return coursename;
	}

	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}

	public Integer getPercentage() {
		return percentage;
	}

	public void setPercentage(Integer percentage) {
		this.percentage = percentage;
	}

	public Integer getAmountpaid() {
		return amountpaid;
	}

	public void setAmountpaid(Integer amountpaid) {
		this.amountpaid = amountpaid;
	}

	public Integer getAmountremaining() {
		return amountremaining;
	}

	public void setAmountremaining(Integer amountremaining) {
		this.amountremaining = amountremaining;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	
//
//	@Query("select * from Training where status = 'true'")
//	public List<Training> findByNameEndsWith() {
//		return null;
//	}
//	
}
