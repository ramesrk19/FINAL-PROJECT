package com.phase4.user;

import org.springframework.data.repository.CrudRepository;

public interface Rolerep extends CrudRepository<Role, Integer>  {

}
