package com.phase4.user;

import javax.persistence.*;

@Entity
public class Userprofile {

	@Id
    private String username;
    
    private String password;
    
    @ManyToOne
    @JoinColumn(name="roleid")
    private Role role;

	public Userprofile() {
		super();
	}

	

	public Userprofile(String username, String password, Role role) {
		super();
		this.username = username;
		this.password = password;
		this.role = role;
	}



	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
    
}
