import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { MentorComponent } from './mentor/mentor.component';
import { AdminComponent } from './admin/admin.component';
import { UsermainpageComponent } from './usermainpage/usermainpage.component';
import { MentormainpageComponent } from './mentormainpage/mentormainpage.component';
import { AdminmainpageComponent } from './adminmainpage/adminmainpage.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { SearchComponent } from './search/search.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserComponent,
    MentorComponent,
    AdminComponent,
    UsermainpageComponent,
    MentormainpageComponent,
    AdminmainpageComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
