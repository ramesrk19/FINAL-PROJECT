import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Time } from '@angular/common';
import { UserService } from '../user.service';

export class Authorization{
  username:string;
  password:string;
  mail:string;
  roleid:Role;
  block:boolean;  //
}
export class Role{
  roleid:number;
  rolename:string;
}

export class Mentor{
username:String;
password:String;
valueFrom:Time;
valueTo:Time;
mobile:String;
training:Training;
skill:Skills;
}
export class Training{
coursename:String;
percentage:Int16Array;
amountpaid:Int16Array;
amountremaining:Int16Array;
status:boolean;
}
export class Skills{
skillname:String;
}


@Component({
  selector: 'app-mentor',
  templateUrl: './mentor.component.html',
  styleUrls: ['./mentor.component.css']
})
export class MentorComponent implements OnInit {

  mname:string;
  mpassword:string;
  printform:boolean = false;

newname:string; 
newpass:string;
mail:string;
newfrom:Time;
newto:Time;
newskill:String;
newphone:string;

arr:String[];

  caption: string;
  invalidmentor: string;
  
  auth:Authorization = new Authorization();
  auth2:Authorization = new Authorization();
  role:Role = new Role();
  ment:Mentor=new Mentor();
  train:Training=new Training();
  skill:Skills=new Skills();


  constructor(private router: Router,private service:UserService) { 
  }

  ngOnInit() {
  }

  mentorlogin(){
    if((this.mname != null)&&(this.mpassword != null)){
      this.service.getlogin(this.mname).subscribe(value=>this.auth2=value as Authorization);
      if((this.mpassword == this.auth2.password)&&(this.auth2.roleid.roleid == 2)){
        if(this.auth2.block==false){   ///
        this.invalidmentor =  "";  
        this.router.navigate(['/mentormainpage',this.mname]);
        }
        else this.invalidmentor = "MENTOR BLOCKED";   ///
      }
      else{
        this.invalidmentor = "Not a registered mentor!!!";
      }
    }
    else{
      this.invalidmentor = "Enter valid details!!!";
    }
  }
  
    mentorregister(){
      this.printform = true;
    }
  
  mentorsignup(){
    if(this.newname!=null && this.newpass!=null && this.newfrom!=null &&
        this.newto!=null && this.newphone!=null ){
      
        this.ment.username = this.newname;
        this.ment.password = this.newpass;
        this.ment.valueFrom = this.newfrom;
        this.ment.valueTo = this.newto;
        this.ment.mobile = this.newphone;
        // this.train.
        // this.ment.training=;
        // this.arr = this.newskill.split(","); 
        // this.ment.skill = this.arr;
        this.auth.username=this.newname;
        this.auth.mail=this.mail;
        this.auth.password=this.newpass;
        this.role.roleid=2;
        this.role.rolename="mentor";
        this.auth.roleid=this.role;
        this.auth.block=false;    ////
        this.service.savesignup(this.auth).subscribe();
        this.service.savementor(this.ment).subscribe();
        this.close();
    }
    else {
      this.caption =  "Enter details!!!";
    }
  }
    close(){
      this.caption = "";
      this.printform = false;
      this.newname = null; 
      this.newpass = null;
      this.newfrom = null;
      this.newto = null;
      this.newphone = null;
      this.mail = null;
      this.newskill = null;
    }

}
