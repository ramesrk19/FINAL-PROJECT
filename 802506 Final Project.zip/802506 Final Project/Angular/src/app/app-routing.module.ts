import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { MentorComponent } from './mentor/mentor.component';
import { AdminComponent } from './admin/admin.component';
import { UsermainpageComponent } from './usermainpage/usermainpage.component';
import { MentormainpageComponent } from './mentormainpage/mentormainpage.component';
import { AdminmainpageComponent } from './adminmainpage/adminmainpage.component';


const routes: Routes = [

  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'user', component: UserComponent },
  { path: 'mentor', component: MentorComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'usermainpage', component: UsermainpageComponent },
  { path: 'mentormainpage/:mname', component: MentormainpageComponent },
  { path: 'adminmainpage', component: AdminmainpageComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
