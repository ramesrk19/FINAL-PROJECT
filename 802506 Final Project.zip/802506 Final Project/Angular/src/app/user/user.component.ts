import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

export class User{
  username:string;
  password:string;
  mail:string;
  roleid:Role;
  block:boolean; //
}
export class Role{
  roleid:number;
  rolename:string;
}
export class Userprofile{
  username:string;
  password:string;
  role:Role;
}

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  uname:string;
  upass:string;
  val:string;
  
  username:string;
  mail:string;
  password:string;
  
  invaliduser:string;
  openform:boolean = false;

  user:User=new User();
  user2:User=new User();
  profile:Userprofile=new Userprofile();
  role:Role=new Role();
  constructor(private router: Router,private service:UserService) {

   }

  ngOnInit() {
  }
  ulogin(){
    if((this.uname==null)||(this.upass==null)){
      this.invaliduser = "Enter valid details!!!";
    }
    else {
      this.service.getlogin(this.uname).subscribe(value=>this.user2=value as User);
      if((this.upass == this.user2.password)&&(this.user2.roleid.roleid == 3)){
        if(this.user2.block==false){   //
        this.invaliduser = "";
        this.router.navigate(['/usermainpage']);
        }
        else this.invaliduser = "USER BLOCKED!!!"; //
      }
      else {
        this.invaliduser = "Not a valid user!!!";
        this.uname = null;
        this.upass = null;
      }
  }}

  //COMPLETE?
  usignup(){
    this.openform = true;
  }
  closeform(){
    this.openform = false;
  }


  onsign(){
    if(this.username!=null && this.mail!=null && this.password!=null){
    this.user.username=this.username;
    this.user.mail=this.mail;
    this.user.password=this.password;
    this.role.roleid=3;
    this.role.rolename="user";
    this.user.roleid=this.role;
    this.user.block = false;   //
    this.service.savesignup(this.user).subscribe();

    this.profile.username=this.username;
    this.profile.password=this.password;
    this.profile.role=this.role;
    this.service.saveuser(this.profile).subscribe();

    // this.service.abc(this.val).subscribe(value=>);

    this.username=null;
    this.mail=null;
    this.password=null;
    this.val="";
    this.closeform();
    }
    else{
      this.val = "Enter valid details";
    }
  }
}
