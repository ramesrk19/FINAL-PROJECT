import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../user.service';
import { Authorization } from '../mentor/mentor.component';
import { Time } from '@angular/common';

export class Mentorprofile{
  username:String;
  password:String;
  valueFrom:Time;
  valueTo:Time;
  mobile:String;
  training:Training;
  skill:Skills;
}
export class Training{
  coursename:String;
  percentage:Int16Array;
  amountpaid:Int16Array;
  amountremaining:Int16Array;
  status:boolean;
  }
  export class Skills{
  skillname:String;
  }

@Component({
  selector: 'app-mentormainpage',
  templateUrl: './mentormainpage.component.html',
  styleUrls: ['./mentormainpage.component.css']
})
export class MentormainpageComponent implements OnInit {
  mentormainprint:number = 0;
  mentor: string[];
  my_name:string = "K.Rameshkumar";
  my_username:string ="rames_rk";
  my_contact: number = 9710082187;
  my_experience:number = 3;
  my_skills:string = "C, Java, SQL, Angular";

  dummy:string;


  private current : string [];
  private completed : string [];
  private mname:string;

  onementor:Mentorprofile=new Mentorprofile();


  constructor(private httpservice : HttpClient,private router: Router,private service: UserService,private route: ActivatedRoute) { }

  ngOnInit(){
    this.dummy = this.route.snapshot.paramMap.get('mname');
    
    this.reloaddata();
  }

  reloaddata(){
    this.service.getmentorcompleted().subscribe(value=>this.completed=value as string[]);
    this.service.getmentorcurrent().subscribe(value=>this.current=value as string[]);
    
  }

  mentorcurrent(){
    this.mentormainprint = 1;
  }
  mentorcompleted(){
    this.mentormainprint = 2;
  }
  about(){
    this.mentormainprint = 3;
    this.service.getdetails(this.dummy).subscribe(value=>this.onementor=value );
  }
  payments(){
    this.mentormainprint = 4;
  }
  goto(){
    window.history.back();
  }
  home(){
    this.mentormainprint = 0;
  }
  
}
