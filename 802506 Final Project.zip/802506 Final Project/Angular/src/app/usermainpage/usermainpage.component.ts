import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';
// import { User } from './User.ts';
import { Observable } from 'rxjs';
import { UserService } from '../user.service';
import { usermainpage } from '../user';

@Component({
  selector: 'app-usermainpage',
  templateUrl: './usermainpage.component.html',
  styleUrls: ['./usermainpage.component.css']
})
export class UsermainpageComponent implements OnInit {

  constructor(private user:UserService){}

  printtable:number=0;
  private mentor:string[];
  private mcompleted:string[];
  private mcurrent:string[];
  private users:string[];

  // skill:string[];
  
  // constructor(private httpservice : HttpClient) { }

  // ngOnInit() {
  //   this.httpservice.get('../../assets/mentordetails.json').subscribe(

  //     data=>{
  //       this.mentor = data as string[];
  //     },
  //     (err : HttpErrorResponse) => {
  //       console.log(err.message);
  //     }
  //   }

  home(){
    this.printtable = 0;
  }
  current(){
    this.printtable = 1;
  }
  completed(){
    this.printtable = 2;
  }
  display(){
    this.printtable = 3;
  }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.user.getmentor().subscribe(value=>this.mentor=value as string[]);
    // this.skill = this.mentor[5];
    this.user.getcompleted().subscribe(value=>this.mcompleted=value as string[]);
    this.user.getcurrent().subscribe(value=>this.mcurrent=value as string[]);
  }

  search(){
   var input, filter, table, tr, td, td1, i, txtValue, txtValue1;
   input = document.getElementById("find");
   filter = input.value.toUpperCase();
   table = document.getElementById("myTable");
   tr = table.getElementsByTagName("tr");
   for (i = 0; i < tr.length; i++) {
     td = tr[i].getElementsByTagName("td")[2];
     td1 = tr[i].getElementsByTagName("td")[1];
     if (td!=null || td1!=null) {
      txtValue = td.textContent || td.innerText;
      txtValue1 = td1.textContent || td1.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1 || txtValue1.toUpperCase().indexOf(filter) > -1) tr[i].style.display = ""; 
      else tr[i].style.display = "none";
     }    
    }
  }
}
