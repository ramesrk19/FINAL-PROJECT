export class usermainpage{
    trainername: string;
    course: string;
    completion: Int16Array;
}