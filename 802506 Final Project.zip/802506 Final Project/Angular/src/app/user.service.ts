import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Adminmainpage } from './addskill';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseURL = "http://localhost:8080/api/phase4";
 
  constructor(private http: HttpClient) { }

  /****************************************USER************************************************* */
  getmentor():Observable<any>{ 
    return this.http.get(`${this.baseURL}-mentor/mentor/profile`);
  }

  getcompleted():Observable<any>{ 
    return this.http.get(`${this.baseURL}-user/user/completed`);
  }

  getcurrent():Observable<any>{ 
    return this.http.get(`${this.baseURL}-user/user/current`);
  }

  /****************************************MENTOR************************************************* */
  getmentorcurrent():Observable<any>{ 
    return this.http.get(`${this.baseURL}-mentor/mentor/current`);
  }

  getmentorcompleted():Observable<any>{ 
    return this.http.get(`${this.baseURL}-mentor/mentor/completed`);
  }

  /****************************************ADMIN************************************************* */
  getblockusers():Observable<any>{ 
    return this.http.get(`${this.baseURL}-user/user/profile`);
  } 

  getblockmentors():Observable<any>{ 
    return this.http.get(`${this.baseURL}-mentor/mentor/profile`);
  } 

  getadminblock():Observable<any>{ 
    return this.http.get(`${this.baseURL}-security/main/all`);
  } 

  savetechnology(tech:string):Observable<any>{
    return this.http.get(`${this.baseURL}-admin/admin/addskill/${tech}`);
  }

  removetechnology(tech:string):Observable<any>{
    return this.http.get(`${this.baseURL}-admin/admin/remove/${tech}`);
  }

  displaytechnology():Observable<any>{
    return this.http.get(`${this.baseURL}-admin/admin/allskills`);
  }

  /****************************************LOGINS************************************************* */
  savesignup(user:object){
    return this.http.post(`${this.baseURL}-security/main/addentry`,user);
  }

  savementor(mentor:object){
    return this.http.post(`${this.baseURL}-mentor/mentor/addentry`,mentor);
  }

  saveuser(user:object){
    return this.http.post(`${this.baseURL}-user/user/addentry`,user);
  }
  
  getlogin(identity:string):Observable<any>{
    return this.http.get(`${this.baseURL}-security/main/${identity}`);
  }

  getdetails(mentor:string):Observable<any>{
    return this.http.get(`${this.baseURL}-mentor/mentor/${mentor}`);
  }

  /****************************************************************************************************** */
  getblock(name:string):Observable<any>{
    return this.http.get(`${this.baseURL}-security/main/block/${name}`);
  }


}
