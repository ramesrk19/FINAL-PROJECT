import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

export class Authorization{
  username:string;
  password:string;
  mail:string;
  roleid:Role;
}
export class Role{
  roleid:number;
  rolename:string;
}

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  aname:string;
  apassword:string;
  invalidadmin: string;

  auth:Authorization = new Authorization();
  role:Role = new Role();

  constructor(private router: Router,private service:UserService) { }

  ngOnInit() {
  }

  adminlogin(){
    if(this.aname!=null && this.apassword!=null)
    {
    this.service.getlogin(this.aname).subscribe(value=>this.auth=value as Authorization);
      if((this.apassword == this.auth.password)&&(this.auth.roleid.roleid == 1)){
        this.invalidadmin = "";
        this.router.navigate(["/adminmainpage"]);
      }
      else{
        this.invalidadmin = "Not a valid Admin!!!";
        this.aname = null;
        this.apassword = null;
      }
    }
    else this.invalidadmin = "Enter valid details!!!";
  }

}
